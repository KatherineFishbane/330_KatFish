import * as main from "./main.js";
window.onload = ()=>{
	console.log("window.onload called");
	main.init();
}